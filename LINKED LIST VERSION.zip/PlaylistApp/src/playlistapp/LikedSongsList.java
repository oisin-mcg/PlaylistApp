/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package playlistapp;

/**
 *
 * @author mcgil
 */

//this is a singly linked list for the "liked songs" playlist which is the core of the application, it contains the function for all of the function for the liked songs.
class LikedSongsList {
    private SongNode head;

    public LikedSongsList() {
        this.head = null;
    }

    // add the song to the liked list
    public void addSong(String song) {
        SongNode newNode = new SongNode(song);
        if (head == null) {
            head = newNode;
        } else {
            SongNode current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // method to get a string representation of the liked songs list
    public String viewLikedSongs() {
        StringBuilder builder = new StringBuilder();
        SongNode current = head;
        while (current != null) {
            builder.append(current.song).append("\n");
            current = current.next;
        }
        return builder.toString();
    }


public boolean deleteSong(String song) {
    if (head == null) return false; // list is empty

    // if the song to delete is the head
    if (head.song.equals(song)) {
        head = head.next;
        return true;
    }

    // search for the song (AND its previous node)
    SongNode current = head;
    while (current.next != null && !current.next.song.equals(song)) {
        current = current.next;
    }

    // if the song was found (not at the end of the list)
    if (current.next != null) {
        current.next = current.next.next; // then skip the deleted node
        return true;
    }

    return false; // song not found
}

//mehod to search the liked songs
public boolean searchSong(String song) {
    SongNode current = head;
    while (current != null) {
        if (current.song.equals(song)) {
            return true;
        }
        current = current.next;
    }
    return false;
}


}


