/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package playlistapp;

/**
 *
 * @author mcgil
 */
import java.util.ArrayList;

public class LikedSongsStack implements ILikedSongsStack {
    private ArrayList<String> stack;

    public LikedSongsStack() {
        this.stack = new ArrayList<>();
    }

    @Override
    public boolean isEmpty() {
        return this.stack.isEmpty();
    }

    @Override
    public void push(String song) {
        this.stack.add(0, song);
    }

    @Override
    public String pop() {
        if (!isEmpty()) {
            return this.stack.remove(0);
        }
        return null; 
    }

    @Override
    public String peek() {
        if (!isEmpty()) {
            return this.stack.get(0);
        }
        return null;
    }

    @Override
    public int size() {
        return this.stack.size();
    }

    @Override
    public String displayStack() {
        StringBuilder builder = new StringBuilder();
        for (String song : this.stack) {
            builder.append(song).append("\n");
        }
        return builder.toString();
    }

    @Override
    public void clear() {
        this.stack.clear();
    }
}
