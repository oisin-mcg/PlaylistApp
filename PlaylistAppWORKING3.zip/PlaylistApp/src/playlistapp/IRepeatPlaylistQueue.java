/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package playlistapp;

/**
 *
 * @author mcgil
 */
public interface IRepeatPlaylistQueue {
    
    // checks if the queue is empty
    boolean isEmpty();

    // adds a song (to the end of the queue) remember FIFO for repeat!
    void enqueue(String song);

    // removes and return the first song from the queue
    String dequeue();

    // returns the first song from the queue without removing it
    String peek();

    // gets the number of songs in the queue (brief requires size function!!)
    int size();

    // display all songs in the queue
    String displayQueue();

    // clears all songs from the queue
    void clear();
}