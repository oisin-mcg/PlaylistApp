/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package playlistapp;

/**
 *
 * @author mcgil
 */
//main app class
public class PlayListApp {

    public static void main(String[] args) {

        //code for testing and demo
        // initialise ADTS
        LikedSongsStack likedSongs = new LikedSongsStack();
        RepeatPlaylistQueue repeatPlaylist = new RepeatPlaylistQueue();
        LikedSongsStack rockPlaylist = new LikedSongsStack();
        LikedSongsStack popPlaylist = new LikedSongsStack();

        // example songs
        String[] songs = {"Song1 - Artist1", "Song2 - Artist2", "Song3 - Artist3"};

        // show adding songs to liked Songs
        System.out.println("Adding songs to Liked Songs...");
        for (String song : songs) {
            likedSongs.push(song);
            System.out.println("Added: " + song);
        }
        System.out.println();

        // display liked Songs
        System.out.println("Liked Songs Playlist:");
        System.out.println(likedSongs.displayStack());
        System.out.println();

        // demo removing a song from liked songs
        System.out.println("Removing the last added song from Liked Songs...");
        likedSongs.pop();
        System.out.println("Liked Songs after removal:");
        System.out.println(likedSongs.displayStack());
        System.out.println();

        // demo adding a song to the repeat playlist
        System.out.println("Adding songs to Repeat Playlist...");
        for (String song : songs) {
            repeatPlaylist.enqueue(song);
            System.out.println("Added to Repeat Playlist: " + song);
        }
        System.out.println();

        // this is a "psuedo" test for searching for a song in liked songs due to the way i implemented the search functionilty, you cant search without the text area
        String searchSong = "Song2 - Artist2";
        System.out.println("Searching for \"" + searchSong + "\" in Liked Songs...");
        System.out.println();

        // adding a song to the Rock playlist from Liked Songs
        System.out.println("Adding the last liked song to the Rock Playlist...");
        if (!likedSongs.isEmpty()) {
            String songToAdd = likedSongs.peek();
            rockPlaylist.push(songToAdd);
            System.out.println("\"" + songToAdd + "\" has been added to the Rock Playlist.");
        }
        System.out.println();

        // display rock playlist
        System.out.println("Rock Playlist:");
        System.out.println(rockPlaylist.displayStack());
        System.out.println();

        //clear the rock playlist
        System.out.println("Clearing Rock Playlist...");
        rockPlaylist.clear();
        System.out.println("Rock Playlist has been cleared.\n");

        // demo Repeat playlist operations
        System.out.println("Adding songs to Repeat Playlist...");
        for (String song : songs) {
            repeatPlaylist.enqueue(song);
            System.out.println("Added to Repeat Playlist: " + song);
        }
        System.out.println();

        // dequeue a song from repeat playlist
        System.out.println("Playing the first song in Repeat Playlist...");
        String playedSong = repeatPlaylist.dequeue();
        System.out.println("Now playing: " + playedSong);
        System.out.println();

        // display updated repeat playlist
        System.out.println("Updated Repeat Playlist:");
        System.out.println(repeatPlaylist.displayQueue());
        System.out.println();

        // this line launches the swing GUI on the event dispatch thread.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new PlaylistGUI().setVisible(true);
            }
        });
    }
}
