/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package playlistapp;

import java.util.LinkedList;

/**
 *
 * @author mcgil
 */
public class RepeatPlaylistQueue implements IRepeatPlaylistQueue {

    private LinkedList<String> queue;

    public RepeatPlaylistQueue() {
        this.queue = new LinkedList<>();
    }

    @Override
    public boolean isEmpty() {
        return this.queue.isEmpty();
    }

    @Override
    public void enqueue(String song) {
        this.queue.addLast(song);
    }

    @Override
    public String dequeue() {
        return this.queue.poll();
    }

    @Override
    public String peek() {
        return this.queue.peek();
    }

    @Override
    public int size() {
        return this.queue.size();
    }

    @Override
    public String displayQueue() {
        StringBuilder builder = new StringBuilder();
        for (String song : this.queue) {
            builder.append(song).append("\n");
        }
        return builder.toString();
    }

    @Override
    public void clear() {
        this.queue.clear();
    }
}
