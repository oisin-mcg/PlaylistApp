/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package playlistapp;

/**
 *
 * @author mcgil
 */

/* stack forr the core playlists (most notably for the liked songs, this is VERY important as the brief specifies 
the system should be limited to only be able to push the last added song to the rock and pop playlists)*/
public interface ILikedSongsStack {

    // checks if the stack is empty
    boolean isEmpty();

    // adds the song to the top of the stack 
    void push(String song);

    /* remove and return the top song from the stack (useful for the search as we will have to use pop to rotate through 
    the stack as stacks cant allow random acces) because of this i would have used a linked list BUT as mentioned the brief specified a limitation(i.e use stack)!!! */
    String pop();

    // returns the top song from the stack without removing it (used for adding songs to the genre playlists)
    String peek();

    // gets the number of songs in the stack (brief requires size function!!)
    int size();

    // displays the contents of the stack
    String displayStack();

    // clears all songs from the stack
    void clear();
}
