/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package playlistapp;

/**
 *
 * @author mcgil
 */
//main app class
public class PlayListApp {

    public static void main(String[] args) {

        //code for testing and demo
        // initialise ADTS
        LikedSongsStack likedSongs = new LikedSongsStack();
        RepeatPlaylistQueue repeatPlaylist = new RepeatPlaylistQueue();
        LikedSongsStack rockPlaylist = new LikedSongsStack();
        LikedSongsStack popPlaylist = new LikedSongsStack();

        // example songs
        String[] songs = {"Song1 - Artist1", "Song2 - Artist2", "Song3 - Artist3"};

        // show adding songs to liked Songs
        System.out.println("Adding songs to liked songs");
        for (String song : songs) {
            likedSongs.push(song);
            System.out.println("Added: " + song);
        }
        System.out.println();

        // display liked Songs
        System.out.println("Liked songs playlist:");
        System.out.println(likedSongs.displayStack());
        System.out.println();

        // demo removing a song from liked songs
        System.out.println("Removing the last added song from liked songs");
        likedSongs.pop();
        System.out.println("Liked songs after removal:");
        System.out.println(likedSongs.displayStack());
        System.out.println();

        // demo adding a song to the repeat playlist
        System.out.println("Adding songs to repeat playlist");
        for (String song : songs) {
            repeatPlaylist.enqueue(song);
            System.out.println("Added to repeat playlist: " + song);
        }
        System.out.println();

        // this is a "psuedo" test for searching for a song in liked songs due to the way i implemented the search functionilty, you cant search without the text area
        String searchSong = "Song2 - Artist2";
        System.out.println("Searching for \"" + searchSong + "\" in liked songs");
        System.out.println();

        // adding a song to the Rock playlist from Liked Songs
        System.out.println("Adding the last liked song to the rock playlist");
        if (!likedSongs.isEmpty()) {
            String songToAdd = likedSongs.peek();
            rockPlaylist.push(songToAdd);
            System.out.println("\"" + songToAdd + "\" has been added to the rock playlist.");
        }
        System.out.println();

        // display rock playlist
        System.out.println("Rock Playlist:");
        System.out.println(rockPlaylist.displayStack());
        System.out.println();

        //clear the rock playlist
        System.out.println("Clearing the rock Playlist");
        rockPlaylist.clear();
        System.out.println("The rock Playlist has been cleared.\n");

        // demo Repeat playlist operations
        System.out.println("Adding songs to the Repeat Playlist");
        for (String song : songs) {
            repeatPlaylist.enqueue(song);
            System.out.println("Added to Repeat playlist: " + song);
        }
        System.out.println();

        // dequeue a song from repeat playlist
        System.out.println("Playing the first song in the repeat playlist");
        String playedSong = repeatPlaylist.dequeue();
        System.out.println("Now Playing: " + playedSong);
        System.out.println();

        // display updated repeat playlist
        System.out.println("Updated repeeat playlist:");
        System.out.println(repeatPlaylist.displayQueue());
        System.out.println();

        //display liked songs and repeat playlist before clearing (after demo)
        System.out.println("Liked songs before clearing:");
        System.out.println(likedSongs.displayStack());
        System.out.println("Repeat playlist before clearing:");
        System.out.println(repeatPlaylist.displayQueue());

        //clearing liked songs and repeat playlist
        System.out.println("Clearing the liked songs and repeat playlists");
        likedSongs.clear();
        repeatPlaylist.clear();

        //verify that liked songs and repeat playlist are cleared
        System.out.println("Liked songs after clearing:");
        if (likedSongs.isEmpty()) {
            System.out.println("The liked songs playlist is empty.");
        } else {
            System.out.println(likedSongs.displayStack());
        }

        System.out.println("Repeat Playlist after clearing:");
        if (repeatPlaylist.isEmpty()) {
            System.out.println("Repeat Playlist is empty.");
        } else {
            System.out.println(repeatPlaylist.displayQueue());
        }

        // this line launches the swing GUI on the event dispatch thread.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new PlaylistGUI().setVisible(true);
            }
        });
    }
}
