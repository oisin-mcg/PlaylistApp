/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package playlistapp;

import java.util.ArrayList;

/**
 *
 * @author mcgil
 */
public class RepeatPlaylistQueue implements IRepeatPlaylistQueue {

    private ArrayList<String> queue;

    public RepeatPlaylistQueue() {
        this.queue = new ArrayList<>();
    }

    @Override
    public boolean isEmpty() {
        return this.queue.isEmpty();
    }

    @Override
    public void enqueue(String song) {
        this.queue.add(song);
    }

    @Override
    public String dequeue() {
        if (!isEmpty()) {
            return this.queue.remove(0);
        }
        return null;
    }

    @Override
    public String peek() {
        if (!isEmpty()) {
            return this.queue.get(0); 
        }
        return null;
    }

    @Override
    public int size() {
        return this.queue.size();
    }

    @Override
    public String displayQueue() {
        StringBuilder builder = new StringBuilder();
        for (String song : this.queue) {
            builder.append(song).append("\n");
        }
        return builder.toString();
    }

    @Override
    public void clear() {
        this.queue.clear();
    }
}
