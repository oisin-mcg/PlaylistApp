/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package playlistapp;

/**
 *
 * @author mcgil
 */

public interface ILikedSongsStack {

    boolean isEmpty();

    void push(String song);

    String pop();

    String peek();

    int size();

    String displayStack();

    void clear();
}
